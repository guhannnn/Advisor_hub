import React from "react";

            import './home.css';

function Home(){
                return(
                <div className="header">
         
                   <h1 className="logo">
                   <a className="title">ADVISOR HUB</a>
                   </h1>
                   <div class="search">
            <form action="#">
                <input type="text"
                    placeholder=" Search "
                    name="search"/>
              
            </form>
        </div>
              <ul className="main-nav">
                <li>
                  <a href="/home">Home</a>
                </li>
                <li>
                  <a href="/i">Top Advisors</a>
                </li>
                <li>
                  <a href="/pro">Profile</a>
                </li>
                <li>
                  <a>Contact</a>
                </li>
              </ul>
              
                  </div>
                  
                  
                ); 
            }
            export default Home;
